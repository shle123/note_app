import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:note_app/models/note.dart';
import 'package:note_app/screens/edit.dart';
import 'package:provider/provider.dart';
import 'package:note_app/Provider/provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> filteredNotes = [];
  bool sorted = false;

  @override
  void initState() {
    super.initState();
    filteredNotes = sampleNotes;
  }

  List<Note> sortNotesByModifiedTime(List<Note> notes) {
    if (sorted) {
      notes.sort((a, b) => a.modifiedTime.compareTo(b.modifiedTime));
    } else {
      notes.sort((b, a) => a.modifiedTime.compareTo(b.modifiedTime));
    }
    sorted = !sorted;
    return notes;
  }

  void onSearchTextChanged(String searchText) {
    setState(() {
      filteredNotes = sampleNotes
          .where((note) =>
              note.content.toLowerCase().contains(searchText.toLowerCase()) ||
              note.title.toLowerCase().contains(searchText.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final uiProvider = Provider.of<UiProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Note App"),
        actions: [
          Tooltip(
            message: 'Sort by Date',
            child: IconButton(
              icon: const Icon(Icons.sort),
              onPressed: () {
                setState(() {
                  filteredNotes = sortNotesByModifiedTime(filteredNotes);
                });
              },
            ),
          ),
          Tooltip(
            message: 'Setting',
            child: IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: filteredNotes.length,
        itemBuilder: (context, index) {
          final note = filteredNotes[index];
          return ListTile(
            title: Text(note.title),
            subtitle: Text(
              DateFormat('yyyy-MM-dd HH:mm').format(note.modifiedTime),
            ),
            trailing: Tooltip(
              message: 'Delete',
              child: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () {
                  setState(() {
                    sampleNotes.remove(note);
                    filteredNotes.remove(note);
                  });
                },
              ),
            ),
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditScreen(note: note),
                ),
              );

              if (result != null && result is Map<String, dynamic>) {
                setState(() {
                  final index =
                      sampleNotes.indexWhere((n) => n.id == result['id']);
                  if (index != -1) {
                    sampleNotes[index] = Note(
                      id: result['id'],
                      title: result['title'],
                      content: result['content'],
                      modifiedTime: DateTime.now(),
                    );
                    filteredNotes = sampleNotes;
                  }
                });
              }
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => const EditScreen(),
            ),
          );

          if (result != null && result is Map<String, dynamic>) {
            setState(() {
              final newNote = Note(
                id: sampleNotes.length,
                title: result['title'],
                content: result['content'],
                modifiedTime: DateTime.now(),
              );
              sampleNotes.add(newNote);
              filteredNotes = sampleNotes;
            });
          }
        },
        elevation: 10,
        backgroundColor: Theme.of(context).colorScheme.secondary,
        child: const Icon(
          Icons.add,
          size: 38,
        ),
      ),
    );
  }
}
