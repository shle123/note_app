class Note {
  int id;
  String title;
  String content;
  DateTime modifiedTime;

  Note({
    required this.id,
    required this.title,
    required this.content,
    required this.modifiedTime,
  });
}

List<Note> sampleNotes = [
  Note(
    id: 0,
    title: "Team Project",
    content: "Shaida Muhammad\nNada Hassan\nAsra Goran",
    modifiedTime: DateTime(2025, 1, 2, 34, 5),
  ),
  Note(
    id: 1,
    title: "Vacation Plans",
    content:
        "🛫 Book flights to Bali\n🏨 Reserve hotel in Ubud\n🧘‍♀️ Try a yoga retreat\n📷 Bring the DSLR camera!",
    modifiedTime: DateTime(2025, 1, 2, 34, 5),
  ),
  Note(
    id: 2,
    title: "Grocery List",
    content: "Milk, Eggs, Bread, Coffee",
    modifiedTime: DateTime.now().subtract(const Duration(hours: 2)),
  ),
  Note(
    id: 3,
    title: "Meeting Notes",
    content: "Discuss project timeline and assign tasks",
    modifiedTime: DateTime.now().subtract(const Duration(days: 1)),
  ),
  Note(
    id: 4,
    title: "Flutter Tips",
    content: "Use ListView.builder for performance, Wrap widgets with Padding",
    modifiedTime: DateTime.now().subtract(const Duration(minutes: 1)),
  ),
];
